package ru.sapteh;

public class JavaFX {
}
