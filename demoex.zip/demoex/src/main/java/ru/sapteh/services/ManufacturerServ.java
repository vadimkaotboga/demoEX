package ru.sapteh.services;

public class ManufacturerServ {
}
