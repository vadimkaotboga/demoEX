package ru.sapteh.dao;

public interface DAO {
}
