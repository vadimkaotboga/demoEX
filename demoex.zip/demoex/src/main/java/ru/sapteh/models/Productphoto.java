package ru.sapteh.models;

import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table (name = "productphoto")
public class Productphoto {
    @Id
    @GeneratedValue
    private int id;
    @Column
    private String photoPath;
}
