package ru.sapteh;

public class Program {
}
